from .essential import dp
from .groups import dp
from .private import dp

__all__ = ["dp"]
