from .basic import dp
from .edit_chat import dp
from .moderate_chat import dp
from .service_messages import dp
from .casino import dp
from .report import dp
from .rating import dp

__all__ = ["dp"]
