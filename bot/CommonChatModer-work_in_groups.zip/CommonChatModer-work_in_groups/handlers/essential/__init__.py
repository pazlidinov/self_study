from .errors import dp
from .metabolism import dp
from .other import dp

__all__ = ["dp"]
